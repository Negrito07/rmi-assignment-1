python c1Rob.py "$@"
